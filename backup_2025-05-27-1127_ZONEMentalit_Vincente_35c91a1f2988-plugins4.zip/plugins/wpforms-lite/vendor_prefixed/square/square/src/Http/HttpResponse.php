<?php

declare (strict_types=1);
namespace WPForms\Vendor\Square\Http;

use WPForms\Vendor\Core\Types\Sdk\CoreResponse;
/**
 * HTTP response received
 */
class HttpResponse extends CoreResponse
{
}
