<?php

namespace WPForms\Vendor\Rs\Json\Pointer;

class NonWalkableJsonException extends \Exception
{
}
